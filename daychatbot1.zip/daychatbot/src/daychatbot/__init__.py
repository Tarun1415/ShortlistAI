from pathlib import Path
import sys


def main() -> None:
    project_dir = Path(__file__).resolve().parents[2]
    sys.path.insert(0, str(project_dir))
    from webapp import main as run_webapp

    run_webapp()
