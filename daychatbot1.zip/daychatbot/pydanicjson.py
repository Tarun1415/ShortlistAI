import os
from pathlib import Path
from dotenv import load_dotenv
from groq import Groq
from pydantic import BaseModel, Field

load_dotenv()
my_api_key = os.getenv("GROQ_API_KEY")
if not my_api_key:
    raise ValueError("GROQ_API_KEY environment variable is not set.")

client = Groq(api_key=my_api_key)
model = "openai/gpt-oss-120b"
role = "user"
text = "hi my name is Tarun, i am a software engineer, i love to code and i love to learn new things, i am a quick learner, i am a team player, i am a good communicator, i am a good problem solver, i am a good listener, i am a good leader, i am a good mentor, i am a good friend, i am a good human being my email id is tarun@example.com, my phone number is +91-1234567890, my address is 123, ABC Street, XYZ City, India, my date of birth is 01-01-1990, my gender is male, my nationality is Indian, my language is English, my hobbies are coding, reading, traveling, my skills are Python, JavaScript, React, Node.js, my education is B.Tech in Computer Science from XYZ University, my work experience is 5 years in ABC Company as a Software Engineer"
prompt = f"""this is customer ticket please extract the information from the {text}"""

class ticket(BaseModel):
    name:str
    email:str
    phone:str
    address:str

schema = ticket.model_json_schema()

response_format = {
    "type": "json_object",
}

system_prompt = f"""You are a helpful assistant.
    Always return the response in valid JSON format.
    Return only JSON without markdown..{schema}"""

message = {
    "role": role,
    "content": prompt
}

massage_system = {
    "role": "system",
    "content": system_prompt 
 }

messages = [massage_system, message]
response = client.chat.completions.create(
    model=model,
    messages=messages,
    temperature=2,
    response_format=response_format
    )

# print(response)

ans = response.choices[0].message.content
print(ans)