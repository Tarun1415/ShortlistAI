# ShortlistAI — Resume Match

A small Flask app for comparing one PDF or DOCX resume with a job description. It extracts the job criteria and resume details, then returns a 0–100 match score with evidence-based strengths, gaps, skill matches, and recommendations. Uploaded files are read in memory and are not saved to disk. Extracted resume and job text is sent to Groq for analysis.

## Run locally

From this directory, add your Groq key to `.env`:

```dotenv
GROQ_API_KEY=your_groq_api_key
GROQ_MODEL=openai/gpt-oss-120b
```

Then install and launch:

```bash
uv sync
uv run python webapp.py
```

Open [http://127.0.0.1:5000](http://127.0.0.1:5000). You can also run `uv run daychatbot`.

Upload a text-based PDF or DOCX file (up to 12 MB), paste the job description, and choose **Analyze match**. Scanned PDFs without selectable text are not OCR processed.

The score is an AI-assisted comparison of supplied, job-related evidence. Use it as one input in a human-led review.
