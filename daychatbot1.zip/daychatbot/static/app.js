const form = document.querySelector("#analysis-form");
const fileInput = document.querySelector("#resume-file");
const uploadZone = document.querySelector("#upload-zone");
const fileMeta = document.querySelector("#file-meta");
const jobDescription = document.querySelector("#job-description");
const charCount = document.querySelector("#char-count");
const analyzeButton = document.querySelector("#analyze-button");
const errorBox = document.querySelector("#form-error");
const emptyState = document.querySelector("#empty-state");
const loadingState = document.querySelector("#loading-state");
const report = document.querySelector("#report");
const MAX_FILE_SIZE = 12 * 1024 * 1024;

function formatBytes(bytes) {
  return bytes < 1024 * 1024
    ? `${Math.max(1, Math.round(bytes / 1024))} KB`
    : `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function showError(message) {
  errorBox.textContent = message;
  errorBox.hidden = false;
}

function setFile(file) {
  if (!file) return;
  const extension = file.name.split(".").pop().toLowerCase();
  if (!["pdf", "docx"].includes(extension)) {
    showError("Choose a PDF or DOCX resume.");
    fileInput.value = "";
    return;
  }
  if (file.size > MAX_FILE_SIZE) {
    showError("That file is too large. Upload a resume under 12 MB.");
    fileInput.value = "";
    return;
  }
  errorBox.hidden = true;
  document.querySelector("#upload-title").textContent = "Resume ready to analyze";
  document.querySelector("#upload-hint").textContent = "Select another file to replace it";
  document.querySelector("#file-name").textContent = file.name;
  document.querySelector("#file-size").textContent = formatBytes(file.size);
  document.querySelector(".file-type").textContent = extension.toUpperCase();
  fileMeta.hidden = false;
  uploadZone.classList.add("has-file");
}

fileInput.addEventListener("change", () => setFile(fileInput.files[0]));
document.querySelector("#remove-file").addEventListener("click", () => {
  fileInput.value = "";
  fileMeta.hidden = true;
  document.querySelector("#upload-title").textContent = "Drop a resume here";
  document.querySelector("#upload-hint").innerHTML = 'or <em>browse files</em> from your computer';
});

jobDescription.addEventListener("input", () => {
  charCount.textContent = `${jobDescription.value.length.toLocaleString()} / 30,000`;
});

["dragenter", "dragover"].forEach((eventName) => {
  uploadZone.addEventListener(eventName, (event) => {
    event.preventDefault();
    uploadZone.classList.add("dragover");
  });
});
["dragleave", "drop"].forEach((eventName) => {
  uploadZone.addEventListener(eventName, (event) => {
    event.preventDefault();
    uploadZone.classList.remove("dragover");
  });
});
uploadZone.addEventListener("drop", (event) => {
  const file = event.dataTransfer.files[0];
  if (!file) return;
  const transfer = new DataTransfer();
  transfer.items.add(file);
  fileInput.files = transfer.files;
  setFile(file);
});

function addListItems(targetId, items, emptyMessage) {
  const target = document.getElementById(targetId);
  target.replaceChildren();
  if (!Array.isArray(items) || items.length === 0) {
    const empty = document.createElement(targetId.includes("skills") ? "span" : "li");
    empty.className = targetId.includes("skills") ? "empty-list" : "empty-list-item";
    empty.textContent = emptyMessage;
    target.append(empty);
    return;
  }
  for (const item of items) {
    const node = document.createElement(targetId.includes("skills") ? "span" : "li");
    node.textContent = item;
    if (targetId === "matching-skills") node.className = "chip";
    if (targetId === "missing-skills") node.className = "chip missing-chip";
    target.append(node);
  }
}

function renderReport(result) {
  const score = Math.max(0, Math.min(100, Math.round(Number(result.score) || 0)));
  const name = result.candidate_name?.trim() || "Candidate";
  document.querySelector("#candidate-name").textContent = name;
  document.querySelector("#person-avatar").textContent = name.slice(0, 1).toUpperCase();
  document.querySelector("#score-ring").style.setProperty("--score", score);
  document.querySelector("#score-value").textContent = score;
  document.querySelector("#summary").textContent = result.summary || "Review the evidence and assessments below.";
  document.querySelector("#verdict").textContent = result.verdict || (score >= 75 ? "Strong alignment" : score >= 50 ? "Some alignment" : "Early-stage fit");
  document.querySelector("#experience-assessment").textContent = result.experience_assessment || "No experience assessment was returned.";
  document.querySelector("#education-assessment").textContent = result.education_assessment || "No education assessment was returned.";

  const matching = Array.isArray(result.matching_skills) ? result.matching_skills : [];
  const missing = Array.isArray(result.missing_skills) ? result.missing_skills : [];
  document.querySelector("#matching-count").textContent = matching.length;
  document.querySelector("#missing-count").textContent = missing.length;
  addListItems("matching-skills", matching, "No direct matches identified");
  addListItems("missing-skills", missing, "No key gaps identified");
  addListItems("strengths-list", result.strengths, "No specific strengths returned.");
  addListItems("gaps-list", result.gaps, "No significant gaps identified.");
  addListItems("recommendations-list", result.recommendations, "No additional recommendations.");

  emptyState.hidden = true;
  loadingState.hidden = true;
  report.hidden = false;
  document.querySelector("#result-panel").scrollIntoView({ behavior: "smooth", block: "start" });
}

function setLoading(active) {
  analyzeButton.disabled = active;
  analyzeButton.classList.toggle("is-loading", active);
  analyzeButton.querySelector(".button-label").textContent = active ? "Analyzing…" : "Analyze match";
  if (active) {
    errorBox.hidden = true;
    report.hidden = true;
    emptyState.hidden = true;
    loadingState.hidden = false;
  } else if (report.hidden) {
    loadingState.hidden = true;
    emptyState.hidden = false;
  }
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  errorBox.hidden = true;
  if (!fileInput.files[0]) {
    showError("Upload a resume to get started.");
    fileInput.focus();
    return;
  }
  if (!jobDescription.value.trim()) {
    showError("Add the job description you want to match against.");
    jobDescription.focus();
    return;
  }

  setLoading(true);
  const body = new FormData(form);
  try {
    const response = await fetch("/api/analyze", { method: "POST", body });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Analysis could not be completed.");
    renderReport(data);
  } catch (error) {
    loadingState.hidden = true;
    emptyState.hidden = false;
    showError(error.message || "Something went wrong. Please try again.");
  } finally {
    setLoading(false);
  }
});

document.querySelector("#new-analysis").addEventListener("click", () => {
  report.hidden = true;
  emptyState.hidden = false;
  document.querySelector("#result-panel").scrollIntoView({ behavior: "smooth", block: "start" });
});
