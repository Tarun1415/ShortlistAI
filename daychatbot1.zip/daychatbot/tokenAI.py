import os
from pathlib import Path
from dotenv import load_dotenv
from groq import Groq

load_dotenv()
my_api_key = os.getenv("GROQ_API_KEY")
if not my_api_key:
    raise ValueError("GROQ_API_KEY environment variable is not set.")

client = Groq(api_key=my_api_key)
model = "openai/gpt-oss-120b"
role = "user"

prompt1 = "hi"
prompt2 = "i love you"
prompt3 = "i marry you, do you accept me?"

prompt = [prompt1, prompt2, prompt3]
for p in prompt:
    message = {
    "role": role,
    "content": p
}

massage_system = {
    "role": "system",
    "content": "are you Human resource manager or brand manager"

}

messages = [massage_system, message]
response = client.chat.completions.create(
    model=model,
    messages=messages,
    temperature=2,
    max_tokens=150
    )

usage = response.usage
print(f"Prompt Tokens: {usage.prompt_tokens}")
print(f"Completion Tokens: {usage.completion_tokens}")
print(f"Total Tokens: {usage.total_tokens}")
print(f"finshed resion: {response.choices[0].finish_reason}")

# print(response)

# ans = response.choices[0].message.content
# print(ans)