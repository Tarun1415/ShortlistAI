"""Flask frontend for the resume matching workflow."""

from __future__ import annotations

from io import BytesIO
from pathlib import Path

from flask import Flask, jsonify, render_template, request
from pydantic import ValidationError
from werkzeug.exceptions import RequestEntityTooLarge

from resume_parser import MAX_DOCUMENT_CHARS, analyze_resume, read_resume


app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 12 * 1024 * 1024
ALLOWED_EXTENSIONS = {".pdf", ".docx"}
MAX_JOB_DESCRIPTION_CHARS = MAX_DOCUMENT_CHARS


@app.get("/")
def index():
    return render_template("index.html")


@app.post("/api/analyze")
def analyze():
    upload = request.files.get("resume")
    job_description = request.form.get("job_description", "").strip()
    if upload is None or not upload.filename:
        return jsonify(error="Upload a resume to get started."), 400
    if not job_description:
        return jsonify(error="Add the job description you want to match against."), 400
    if len(job_description) > MAX_JOB_DESCRIPTION_CHARS:
        return jsonify(error=f"Keep the job description under {MAX_JOB_DESCRIPTION_CHARS:,} characters."), 400

    filename = upload.filename.rsplit("/", 1)[-1].rsplit("\\", 1)[-1]
    if Path(filename).suffix.lower() not in ALLOWED_EXTENSIONS:
        return jsonify(error="Choose a PDF or DOCX resume."), 400
    raw_file = upload.read()
    if not raw_file:
        return jsonify(error="The uploaded file is empty."), 400

    try:
        resume_text = read_resume(BytesIO(raw_file), filename)
        if not resume_text.strip():
            return jsonify(error="No selectable text was found. If this is a scanned PDF, upload a text-based PDF or DOCX."), 422
        result = analyze_resume(resume_text[:MAX_DOCUMENT_CHARS], job_description)
        return jsonify(result.model_dump(mode="json"))
    except (ValueError, ValidationError) as error:
        return jsonify(error=str(error)), 422
    except Exception as error:
        app.logger.exception("Resume analysis failed")
        message = str(error)
        if "GROQ_API_KEY" in message:
            return jsonify(error=message), 503
        return jsonify(error="We couldn't analyze that file right now. Check the file and try again."), 502


@app.errorhandler(RequestEntityTooLarge)
def request_too_large(_error):
    return jsonify(error="That file is too large. Upload a resume under 12 MB."), 413


def main() -> None:
    app.run(host="127.0.0.1", port=5000, debug=False)


if __name__ == "__main__":
    main()
